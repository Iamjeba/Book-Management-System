-- Book Sold
DECLARE
  ItemId Sales.SalesId%TYPE := &y; 
  ItemSold Sales.SalesQuantity%TYPE;
  SoldBookId Books.BookId%TYPE;
  ItemQuantity Books.BookQuantity%TYPE;
  ItemSoldQuantity Books.BookQuantity%TYPE;
BEGIN
  SELECT SalesQuantity INTO ItemSold FROM Sales WHERE SalesId = ItemId; 
  SELECT BookId INTO SoldBookId FROM Sales WHERE SalesId = ItemId;
  SELECT BookQuantity INTO ItemQuantity FROM Books WHERE BookId = SoldBookId;  

  ItemSoldQuantity := ItemQuantity - ItemSold;

  UPDATE Books SET BookQuantity = ItemSoldQuantity where BookId = SoldBookId;
  DBMS_OUTPUT.PUT_LINE('Book Quantity = ' || ItemSoldQuantity);

END;
/
commit;

SELECT * FROM Books;
select * from Sales;
-- Book Sold