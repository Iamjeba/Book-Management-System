-- SELECT Customer Start

ACCEPT x number prompt "Before update, CID: " 

DECLARE
   CUS Customers.CID%Type := &x;
BEGIN
   DBMS_OUTPUT.PUT_LINE('You entered: ' || CUS);

   for R in (Select * from Customers where CID = CUS)
	LOOP
	  DBMS_OUTPUT.PUT_LINE('CID: ' || R.CID || ' C_NAME: ' || R.CNAME);
	end loop;
END;
/

-- SELECT Customer End

-- UPDATE Customer Start

ACCEPT x number prompt "Enter the CID you want to update: "
ACCEPT y CHAR FORMAT 'A20' PROMPT 'cname:  '

--UPDATE Customers SET CNAME = &y where CID = &x;
--DBMS_OUTPUT.PUT_LINE('CID: ' || Customers.CID || ' C_NAME: ' || Customers.CNAME);

DECLARE
   CUS Customers.CID%Type := &x;
   CUS_NAME Customers.CNAME%Type := &y;
BEGIN
   DBMS_OUTPUT.PUT_LINE('You entered CID: ' || CUS);
   DBMS_OUTPUT.PUT_LINE('You entered CNAME: ' || CUS_NAME);

   UPDATE Customers SET CNAME = CUS_NAME where CID = CUS;
   DBMS_OUTPUT.PUT_LINE('After Update');
   for R in (Select * from Customers where CID = CUS)
	LOOP
	  DBMS_OUTPUT.PUT_LINE('CID: ' || R.CID || ' C_NAME: ' || R.CNAME);
	end loop;
END;
/
-- UPDATE Customer Start

Select * from Customers;
