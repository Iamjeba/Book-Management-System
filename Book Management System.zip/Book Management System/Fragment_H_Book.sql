SET SERVEROUTPUT ON;
SET VERIFY OFF;

DROP TABLE Books1 CASCADE CONSTRAINT;
DROP TABLE Books2 CASCADE CONSTRAINT;

CREATE TABLE Books1(
   BookId INTEGER, 
   BId INTEGER, 
   Bookname VARCHAR2(30), 
   Bookauthor VARCHAR2(30), 
   BookQuantity INTEGER,
   Bookprice INTEGER,
     primary key (BookId)
);

CREATE OR REPLACE TRIGGER Books1Trigg 
After INSERT 
ON Books1
DECLARE
BEGIN
	DBMS_OUTPUT.PUT_LINE('Books1 Table is created with values');
END;
/
INSERT INTO Books1 VALUES (101, 1, 'The Great gatsby', 'karim', 100, 120);
INSERT INTO Books1 VALUES (102, 1, 'B', 'rahim', 200, 170);
INSERT INTO Books1 VALUES (103, 1, 'C', 'Jeba', 300, 180);

------------------------------------------------------------------------------------
CREATE TABLE Books2(
   BookId INTEGER, 
   BId INTEGER, 
   Bookname VARCHAR2(30), 
   Bookauthor VARCHAR2(30), 
   BookQuantity INTEGER,
   Bookprice INTEGER,
     primary key (BookId)
);

CREATE OR REPLACE TRIGGER Books2Trigg 
After INSERT 
ON Books2
DECLARE
BEGIN
	DBMS_OUTPUT.PUT_LINE('Books2 Table is created with values');
END;
/
INSERT INTO Books2 VALUES (104, 2, 'D', 'tuli', 400, 100);
INSERT INTO Books2 VALUES (105, 2, 'E', 'sounava', 500, 200);
INSERT INTO Books2 VALUES (106, 2, 'F', 'wasi', 600, 320);



--SELECT * from Books1 UNION SELECT * from Books2;

	 
BEGIN
	for R in (SELECT * from Books1 UNION SELECT * from Books2)
	--horizontal fragmentation
	LOOP
	    DBMS_OUTPUT.PUT_LINE('------------------------------------------------------');
		DBMS_OUTPUT.PUT_LINE('Book Id: ' || R.BookId);
		DBMS_OUTPUT.PUT_LINE('Book Name: ' || R.Bookname);
		DBMS_OUTPUT.PUT_LINE('Branch Id: ' || R.BId);
		DBMS_OUTPUT.PUT_LINE('Author: ' || R.BookQuantity);
		DBMS_OUTPUT.PUT_LINE('Quantity: ' || R.BookQuantity);
		DBMS_OUTPUT.PUT_LINE('Price:'|| R.Bookprice);
		DBMS_OUTPUT.PUT_LINE('------------------------------------------------------');

	END LOOP;
END;
/
commit;