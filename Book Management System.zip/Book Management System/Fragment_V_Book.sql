SET SERVEROUTPUT ON;
SET VERIFY OFF;

DROP TABLE Books1 CASCADE CONSTRAINT;
DROP TABLE Books2 CASCADE CONSTRAINT;

CREATE TABLE Books1(
   BookId INTEGER, 
   BId INTEGER, 
   Bookname VARCHAR2(30), 
     primary key (BookId)
);

CREATE OR REPLACE TRIGGER Books1Trigg 
After INSERT 
ON Books1
DECLARE
BEGIN
	DBMS_OUTPUT.PUT_LINE('Books1 Table is created with values');
END;
/
INSERT INTO Books1 VALUES (101, 1, 'The Great gatsby');
INSERT INTO Books1 VALUES (102, 1, 'B');
INSERT INTO Books1 VALUES (103, 1, 'C');
INSERT INTO Books1 VALUES (104, 2, 'D');
INSERT INTO Books1 VALUES (105, 2, 'E');
INSERT INTO Books1 VALUES (106, 2, 'F');

------------------------------------------------------------------------------------
CREATE TABLE Books2(
   BookId INTEGER,  
   Bookauthor VARCHAR2(30), 
   BookQuantity INTEGER,
   Bookprice INTEGER,
     primary key (BookId)
);

CREATE OR REPLACE TRIGGER Books2Trigg 
After INSERT 
ON Books2
DECLARE
BEGIN
	DBMS_OUTPUT.PUT_LINE('Books2 Table is created with values');
END;
/
INSERT INTO Books2 VALUES (101, 'karim', 100, 120);
INSERT INTO Books2 VALUES (102, 'rahim', 200, 170);
INSERT INTO Books2 VALUES (103, 'Jeba', 300, 180);
INSERT INTO Books2 VALUES (104, 'tuli', 400, 100);
INSERT INTO Books2 VALUES (105, 'sounava', 500, 200);
INSERT INTO Books2 VALUES (106, 'wasi', 600, 320);



SELECT Books1.BookId, Books1.BId, Books1.Bookname, 
       Books2.Bookauthor, Books2.BookQuantity, Books2.Bookprice 
       from Books1 full outer join Books2 on Books1.BookId = Books2.BookId;

	 
BEGIN
	for R in (SELECT Books1.BookId, Books1.BId, Books1.Bookname, 
       		     Books2.Bookauthor, Books2.BookQuantity, Books2.Bookprice 
       		     from Books1 full outer join Books2 on Books1.BookId = Books2.BookId
		   )
	--horizontal fragmentation
	LOOP
	    DBMS_OUTPUT.PUT_LINE('------------------------------------------------------');
		DBMS_OUTPUT.PUT_LINE('Book Id: ' || R.BookId);
		DBMS_OUTPUT.PUT_LINE('Book Name: ' || R.Bookname);
		DBMS_OUTPUT.PUT_LINE('Branch Id: ' || R.BId);
		DBMS_OUTPUT.PUT_LINE('Author: ' || R.BookQuantity);
		DBMS_OUTPUT.PUT_LINE('Quantity: ' || R.BookQuantity);
		DBMS_OUTPUT.PUT_LINE('Price:'|| R.Bookprice);
		DBMS_OUTPUT.PUT_LINE('------------------------------------------------------');

	END LOOP;
END;
/
commit;