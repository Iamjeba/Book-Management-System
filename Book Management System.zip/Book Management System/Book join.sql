CREATE TABLE Books1(
   BookId INTEGER, 
   BId INTEGER, 
   Bookname VARCHAR2(30), 
     primary key (BookId)
);

CREATE OR REPLACE TRIGGER Books1Trigg 
After INSERT 
ON Books1
DECLARE
BEGIN
	DBMS_OUTPUT.PUT_LINE('Books1 Table is created with values');
END;
/
INSERT INTO Books1 VALUES (101, 1, 'The Great gatsby');
INSERT INTO Books1 VALUES (102, 1, 'Brave new world');
INSERT INTO Books1 VALUES (103, 1, 'Beloved');
INSERT INTO Books1 VALUES (104, 2, 'The grapes of wrath');
INSERT INTO Books1 VALUES (105, 2, 'In cold blood');
INSERT INTO Books1 VALUES (106, 2, 'As i lay dying');



DECLARE

BEGIN
	 for R in (SELECT * from Books1 join Books2@site_link on Books1.Book_id=Books2.Book_id@site_link)
	 LOOP
		DBMS_OUTPUT.PUT_LINE(R.name);
	 END LOOP;
END;
commit;
/silent