-- Count Books
ACCEPT i number prompt "Please Enter Branch ID: " 
DECLARE
   ItemBranchId Branch.BId%TYPE := &i;
   ItemCount Books.BookQuantity%TYPE := 0;
   ItemBname Branch.Bname%TYPE;
   ItemQnty Books.BookQuantity%TYPE;
BEGIN
   DBMS_OUTPUT.PUT_LINE('You entered Bid: ' || ItemBranchId);

   --SELECT COUNT(*) INTO ItemCount FROM Books WHERE BId = ItemBranchId;

   for R in (SELECT * FROM Books WHERE BId = ItemBranchId)
	LOOP
        SELECT Books.BookQuantity INTO ItemQnty FROM BOOKS WHERE BookId = R.BookId;
	  
	  ItemCount := ItemCount + ItemQnty;
	END loop;

   SELECT Bname INTO ItemBname FROM Branch WHERE BId = ItemBranchId;
   
   DBMS_OUTPUT.PUT_LINE('Bname: ' || ItemBname || ' Book Count: ' || ItemCount);

   --Select * from Books where BId = ItemBranchId;
END;
/
commit;
--Select * from Books where BId = i;
--Select * from Branch where BId = 1;
--select * from Branch;
select * from Books;

-- Count Books