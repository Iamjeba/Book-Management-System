-- Discount
ACCEPT x number prompt "If you want to buy any book please enter 1: " 
ACCEPT y number prompt "Please Enter Sales ID: " 
ACCEPT a number prompt "Please Enter Branch ID: " 
ACCEPT b number prompt "Please Enter CUstomer ID: " 
ACCEPT c number prompt "Please Enter Book ID: " 
ACCEPT d number prompt "Please Enter Sales Quantity: " 
ACCEPT e CHAR FORMAT 'A20' PROMPT "Please Enter Sales Sales Date: " 

DECLARE
  ItemBranchId Branch.BId%TYPE := &a;
  ItemCustomer Customers.CId%TYPE := &b;
  ItemId Sales.SalesId%TYPE := &y; 
  ItemSold Sales.SalesQuantity%TYPE := &d;
  ItemPrice Books.Bookprice%TYPE;
  SoldBookId Books.BookId%TYPE := &c;
  ItemDiscount Sales.Discount%TYPE;
  ItemSoldDate Sales.SalesDate%TYPE := &e;
  --DiscountItemPrice Books.Bookprice%TYPE;
BEGIN
  INSERT INTO Sales VALUES (ItemId, ItemBranchId, ItemCustomer, SoldBookId, ItemSold, ItemSoldDate, 0.0);

  --SELECT SalesQuantity INTO ItemSold FROM Sales WHERE SalesId = ItemId; 
  --SELECT BookId INTO SoldBookId FROM Sales WHERE SalesId = ItemId;
  SELECT Bookprice INTO ItemPrice FROM Books WHERE BookId = SoldBookId;  

  ItemDiscount := ItemPrice * 0.3;
  ItemPrice := ItemPrice - ItemDiscount;

  if (ItemSold >= 3) THEN
     UPDATE Sales SET Discount = ItemDiscount where SalesId = ItemId;
     --SELECT Discount INTO DiscountItemPrice FROM Sales WHERE SalesId = ItemId;
     DBMS_OUTPUT.PUT_LINE('Congratualation You will get 30% Discount on the Sale. Book Price = ' || ItemPrice);
  ELSE
     DBMS_OUTPUT.PUT_LINE('For Discount You Have to buy at least 3 books');
  END if;
END;
/
-- Discount

-- Update Customer Balance
DECLARE
  ItemCustomerId Customers.CId%TYPE := &b;
  ItemSold Sales.SalesQuantity%TYPE := &d;
  ItemPrice Books.Bookprice%TYPE;
  ItemBalance Customers.Balance%TYPE;
  SoldBookId Books.BookId%TYPE := &c;
  ItemDiscount Sales.Discount%TYPE;
BEGIN
  SELECT Bookprice INTO ItemPrice FROM Books WHERE BookId = SoldBookId;  
  SELECT Balance INTO ItemBalance FROM Customers WHERE CId = ItemCustomerId;  

  ItemPrice := ItemPrice * ItemSold;

  if (ItemSold >= 3) THEN
     ItemDiscount := ItemPrice * 0.3;
     ItemPrice := ItemPrice - ItemDiscount;
     DBMS_OUTPUT.PUT_LINE('Congratualation You will get 30% Discount on the Sale. Book Price = ' || ItemPrice);
  ELSE
     DBMS_OUTPUT.PUT_LINE('For Discount You Have to buy at least 3 books');
  END if;

  ItemPrice := ItemPrice + ItemBalance;

  UPDATE Customers SET Balance = ItemPrice where CId = ItemCustomerId;
  DBMS_OUTPUT.PUT_LINE('Customer Balence Updated');

END;
/
commit;
select * from sales;

SELECT * FROM CUSTOMERS;
select * from books;
-- Update Customer Balance