ACCEPT x number prompt "Enter the CID info you want to delete: "

--UPDATE Customers SET CNAME = &y where CID = &x;
--DBMS_OUTPUT.PUT_LINE('CID: ' || Customers.CID || ' C_NAME: ' || Customers.CNAME);

DECLARE
   CUS Customers.CID%Type := &x;
BEGIN
   DBMS_OUTPUT.PUT_LINE('You entered CID: ' || CUS);

   Delete from Customers where CID = CUS;
   DBMS_OUTPUT.PUT_LINE('After Delete');
 
END;
/
commit;
Select * from Customers;

