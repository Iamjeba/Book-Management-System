SET SERVEROUTPUT ON;
SET VERIFY OFF;

DROP TABLE Customers CASCADE CONSTRAINT;
DROP TABLE Books CASCADE CONSTRAINT;
DROP TABLE Sales CASCADE CONSTRAINT;
DROP TABLE Branch CASCADE CONSTRAINT;

CREATE TABLE Customers(
    CId INTEGER,
    Cname VARCHAR(40),
    CmobileNo VARCHAR(40),
    Balance INTEGER,
    Bname VARCHAR(40),
	primary key (CId)
);

CREATE OR REPLACE TRIGGER customersTrigg 
After INSERT 
ON Customers
DECLARE
BEGIN
	DBMS_OUTPUT.PUT_LINE('Customer Table is created with values');
END;
/
INSERT INTO Customers VALUES (1, 'A', '10000000', 100, 'Dhaka');
INSERT INTO Customers VALUES (2, 'B', '20000000', 200, 'Dhaka');
INSERT INTO Customers VALUES (3, 'C', '30000000', 300, 'Dhaka');
INSERT INTO Customers VALUES (4, 'D', '40000000', 400, 'Rajshahi');
INSERT INTO Customers VALUES (5, 'E', '50000000', 500, 'Rajshahi');
INSERT INTO Customers VALUES (6, 'F', '60000000', 600, 'Rajshahi');


Select * from Customers;

CREATE TABLE Branch(
    BId INTEGER , 
Bname VARCHAR2(30), 
Bmanager VARCHAR2(30), 
Location VARCHAR2(30), 
BmobileNo VARCHAR2(30),
	primary key (BId)
);

CREATE OR REPLACE TRIGGER BranchTrigg 
After INSERT 
ON Customers
DECLARE
BEGIN
	DBMS_OUTPUT.PUT_LINE('Branch Table is created with values');
END;
/
INSERT INTO Branch VALUES (1, 'A', 'Misho', 'Dhaka','12345890');
INSERT INTO Branch VALUES (2, 'B', 'izma',  'Dhaka','9748085433');
INSERT INTO Branch VALUES (3, 'C', 'Jeba',  'Dhaka','597547321');
INSERT INTO Branch VALUES (4, 'D', 'Riyad', 'Rajshahi','01872567');
INSERT INTO Branch VALUES (5, 'E', 'ILhan', 'Rajshahi','0891778219');
INSERT INTO Branch VALUES (6, 'F', 'Sounava','Rajshahi','892089754');


Select * from Branch;


CREATE TABLE Books(
   BookId INTEGER, 
   BId INTEGER, 
   Bookname VARCHAR2(30), 
   Bookauthor VARCHAR2(30), 
   BookQuantity INTEGER,
   Bookprice INTEGER,
     primary key (BookId)
);

CREATE OR REPLACE TRIGGER BooksTrigg 
After INSERT 
ON Books
DECLARE
BEGIN
	DBMS_OUTPUT.PUT_LINE('Books Table is created with values');
END;
/
INSERT INTO Books VALUES (101, 1, 'The Great gatsby', 'karim', 100, 120);
INSERT INTO Books VALUES (102, 1, 'Brave new world', 'aldos', 200, 170);
INSERT INTO Books VALUES (103, 1, 'Beloved', 'Toni', 300, 180);
INSERT INTO Books VALUES (104, 2, 'The Grapes of Wrath', 'Jhon', 400, 100);
INSERT INTO Books VALUES (105, 2, 'In cold Blood', 'Truman', 500, 200);
INSERT INTO Books VALUES (106, 2, 'As i Lay dying', 'William', 600, 320);


Select * from Books;

-- Create Sales Table

CREATE TABLE Sales(
   SalesId INTEGER, 
   BId INTEGER, 
   CId INTEGER, 
   BookId INTEGER, 
   SalesQuantity INTEGER,
   SalesDate VARCHAR(100), 
   Discount FLOAT,
   primary key (SalesId)
);

CREATE OR REPLACE TRIGGER SalesTrigg 
After INSERT 
ON Sales
DECLARE
BEGIN
	DBMS_OUTPUT.PUT_LINE('Sales Table is created with values');
END;
/
INSERT INTO Sales VALUES (1, 1, 1, 101, 1, '10-01-23', 0.0);
INSERT INTO Sales VALUES (2, 1, 1, 102, 3, '10-01-23', 0.0);
INSERT INTO Sales VALUES (3, 1, 2, 101, 4, '10-01-23', 0.0);
INSERT INTO Sales VALUES (4, 2, 2, 103, 2, '10-01-23', 0.0);
INSERT INTO Sales VALUES (5, 2, 3, 104, 1, '10-01-23', 0.0);
INSERT INTO Sales VALUES (6, 2, 4, 105, 1, '10-01-23', 0.0);

Select * from Sales;
commit;

