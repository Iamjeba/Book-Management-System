-- Count Books
ACCEPT cus number prompt "Please Customer ID: " 
DECLARE
   ItemCusId Customers.CId%TYPE := &cus;
   ItemBalance Customers.Balance%TYPE;
   ItemBname Customers.Bname%TYPE;
   ItemCname Customers.Cname%TYPE;
   ItemQnty Books.BookQuantity%TYPE := 0;
   ItemSalesQnty Books.BookQuantity%TYPE;
BEGIN
   --DBMS_OUTPUT.PUT_LINE('You entered Cid: ' || ItemCusId);

   SELECT Customers.Cname INTO ItemCname FROM Customers WHERE CId = ItemCusId;
   SELECT Customers.Bname INTO ItemBname FROM Customers WHERE CId = ItemCusId;
   SELECT Customers.Balance INTO ItemBalance FROM Customers WHERE CId = ItemCusId;

   SELECT Sum(Sales.SalesQuantity) INTO ItemQnty FROM Sales WHERE CId = ItemCusId;

   
   DBMS_OUTPUT.PUT_LINE('Cname: ' || ItemCname || ' Branch Name: ' || ItemBname);

   DBMS_OUTPUT.PUT_LINE('Balance: ' || ItemBalance || ' Quantity: ' || ItemQnty);

   --Select * from Books where BId = ItemBranchId;
END;
/
commit;
--Select * from Books where BId = i;
--Select * from Branch where BId = 1;
--select * from Branch;
--select * from Books;

-- Count Books