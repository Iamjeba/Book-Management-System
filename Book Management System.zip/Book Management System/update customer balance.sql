-- Update Customer Balance
DECLARE
  ItemCustomerId Customers.CId%TYPE := &b;
  ItemSold Sales.SalesQuantity%TYPE := &d;
  ItemPrice Books.Bookprice%TYPE;
  SoldBookId Books.BookId%TYPE := &c;
  ItemDiscount Sales.Discount%TYPE;
BEGIN
  SELECT Bookprice INTO ItemPrice FROM Books WHERE BookId = SoldBookId;  

  if (ItemSold >= 3) THEN
     ItemDiscount := ItemPrice * 0.3;
     ItemPrice := ItemPrice - ItemDiscount;
     DBMS_OUTPUT.PUT_LINE('Congratualation You will get 30% Discount on the Sale. Book Price = ' || ItemPrice);
  ELSE
     DBMS_OUTPUT.PUT_LINE('For Discount You Have to buy at least 3 books');
  END if;

  UPDATE Customers SET Balance = ItemPrice where CId = ItemCustomerId;
  DBMS_OUTPUT.PUT_LINE('Customer Balence Updated');

END;
/
SELECT * FROM CUSTOMERS;
-- Update Customer Balance